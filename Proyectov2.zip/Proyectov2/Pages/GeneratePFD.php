<?php
include 'sendmail.php';
include 'emailsaver.php';

$id = $_POST['id'];
$idusr = $_POST['idusr'];
if ($_POST) {
    require ('fpdf/fpdf.php');

    $title = 'Orden de Compra';
    $nom1 = $_POST['Nombre'];
    $pic1 = $_POST['Precio'];
    $pic2 = '$';
    $pic2 .= $pic1;
    $mark = '[Cosmic Music]';

    $pdf = new FPDF();
    $pdf -> AddPage();
    $pdf -> SetTitle($title);

    $pdf -> SetFont('Arial','B',21);
    $j = $pdf -> GetStringWidth($mark) +6;
    $pdf -> SetTextColor(0,0,0,1);
    $pdf -> SetX((210-$j)/2);
    $pdf -> Cell($j,9,$mark,0,1,'C',false);

    $pdf -> SetFont('Arial', 'B',15);

    $w = $pdf -> GetStringWidth($title) + 6;
    $a = $pdf -> GetStringWidth($nom1) + 6;
    $b = $pdf -> GetStringWidth($pic1) + 6;
    $pdf -> SetTextColor(255,255,255,1);
    $pdf -> SetX((210-$w)/2);
    $pdf -> Cell($w,9,$title,1,1,'C',true);
    $pdf -> Ln(10);
    $pdf -> SetTextColor(0,0,0,1);
    $pdf -> SetFont('Arial','B', 12);

    $pdf -> SetX((170-$a)/2);
    $pdf -> Cell($a,9,'Producto',1,0,'L',false);
    $pdf -> Cell($a,9,$nom1,1,1,'L',false);
    $pdf -> SetX((170-$a)/2);
    $pdf -> Cell($a,9,'Precio',1,0,'C',false);
    $pdf -> Cell($a,9,$pic2,1,1,'L',false);

    $pdf -> SetX((170-$a)/2);
    $pdf -> Cell($a,9,'Subtotal',1,0,'C',false);
    $pdf -> Cell($a,9,$pic2,1,1,'L',false);
    $pdf -> SetX((170-$a)/2);
    $pdf -> Cell($a,9,'Total',1,0,'C',false);
    $pdf -> Cell($a,9,$pic2,1,1,'L',false);

    $pdf -> Output("pdf/Orden$id.pdf","F");
}
$email = emailSaver($idusr);
sendMail($id,$email);

header("Location: ../Pages/ProyectoTutMusica.html");
?>