<?php



function emailSaver($id){

    include '../php/conexion.php';
    $usr = mysqli_query($con, "SELECT * FROM usuarios WHERE id = '$id'");
    $a = mysqli_fetch_array($usr);
    $b = $a['email'];
    return $b;
}




?>