<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../Pages/Style.css">
</head>
<body>
<nav class="navegation">
    <div class="right">
        <ul>
            <li><a href="../Forms/Login.html">Login</a></li>
            <li><a href="../Forms/Registro.html">Registrate</a></li>
        </ul>
    </div>
    <ul>
        <li><a href="../index.html">Home</a></li>
        <li><a href="../Pages/Cursos.php">Cursos</a></li><!--productos-->
        <li><a href="../Pages/Carrito.php">Carrito</a></li>
        <li><a href="../Pages/Ubicacion.html">Encuentranos</a></li>
    </ul>
</nav>

<?php
session_start();
include '../php/conexion.php';

if (isset($_SESSION['id_usr'])) {
    $usrID = $_SESSION['id_usr'];
    $result = mysqli_query($con, "SELECT * FROM cart WHERE userid = '$usrID'");
while($row = $result->fetch_assoc()){
?>
<div>

    <div>    
        <form action="GeneratePFD.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"> <br><br>
        <input type="hidden" name="iDProd" value="<?php echo $row['idprod']; ?>"> <br><br>
        <input type="hidden" name="idusr" value="<?php echo $row['userid']; ?>"> <br><br>
        <input name="Nombre"  type="text" id="Nombre" value="<?php echo $row['nameProd'];?>" readonly onmousedown="return false;"/><br><br>
        <label>Precio: $</label>
        <input name="Precio" type="text" id="Precio" value="<?php echo $row['priceprod']; ?>" readonly onmousedown="return false;"/><br><br><br>
        <input type="submit" value="Comprar">
        </form>
        
        
        
    </div>   
    <?php
    }
    }
    else {
        $a = '<p>';
        $a .= 'Inicia Sesion para mostrar carrito';
        $a .= '</p>';
        echo $a;
    }
    ?>
    </div>




</body>
</html>