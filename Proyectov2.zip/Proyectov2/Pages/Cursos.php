<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music</title>
    <link rel="stylesheet" href="Style.css">
    <link rel="stylesheet" href="StyleCursos.css">
</head>
<nav class="navegation">
    <div class="right">
        <ul>
            <li><a href="../Forms/Login.html">Login</a></li>
            <li><a href="../Forms/Registro.html">Registrate</a></li>
        </ul>
    </div>
    <ul>
        <li><a href="../index.html">Home</a></li>
        <li><a href="../Pages/Cursos.php">Cursos</a></li><!--productos-->
        <li><a href="../Pages/Carrito.php">Carrito</a></li>
        <li><a href="../Pages/Ubicacion.html">Encuentranos</a></li>
    </ul>
</nav>
<body>
    <p>Cursos actuales</p>
    <?php

include ("../php/conexion.php");

    $query = "SELECT * FROM product";
    $resultado = $con->query($query);
    while($row = $resultado->fetch_assoc()){
    //var_dump($row);
?> 

<div class="coteiner">

    <div class="card22">    
        <form action="../php/AddCarrito.php" method="POST">
        <input type="hidden" name="iDProd" value="<?php echo $row['id']; ?>"> <br><br>
        <input name="Nombre"  type="text" id="Nombre" value="<?php echo $row['name'];?>" readonly onmousedown="return false;"/><br><br>
        <td><img width="90" height="90" src="data:image/jpg;base64,<?php echo base64_encode($row['images']); ?>" /></td><br>
        <label>Descripcion:</label><br>
        <input neme="Descripcion" type="text" id="Descripcion" style="WIDTH: 200px; HEIGHT: 50px" size="20"  value="<?php echo $row['descripcion']; ?>" readonly onmousedown="return false;"/><br><br>
        <label>Precio: $</label>
        <input name="Precio" type="text" id="Precio" value="<?php echo $row['price']; ?>" readonly onmousedown="return false;"/><br><br><br>    
        
        <button id="Button" type="submit">Agregar al carito</button><br><br>
        </form>
        
        
        
    </div>   
    <?php
    }
    ?>
        </div>

</html>
