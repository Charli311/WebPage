'use strict'
//var: se usa como para variables globales; let: se usa para variables locales (sitios, funciones)[temporales]; 

var nombre = "Carlos"; //String
var edad = 20; //number
var empleado = false; //Boolean
var salario = 50.50; //number

//Imprime en consola las variables
/*console.log(nombre);
console.log(typeof nombre);
console.log(edad);
console.log(typeof edad);
console.log(empleado);
console.log(typeof empleado);
console.log(salario);
console.log(typeof salario);*/

//Permite recibir datos del cuadro de texto
nombre = prompt("¿Como te llamas?");
edad = parseInt(prompt("¿Cual es tu edad?"));
empleado = Boolean(prompt("¿Eres un empleado? T/F"));
salario = parseFloat(prompt("¿Cual es tu salario?"));

console.log(nombre);
console.log(typeof nombre);
console.log(edad);
console.log(typeof edad);
console.log(empleado);
console.log(typeof empleado);
console.log(salario);
console.log(typeof salario);

var n1, n2, res;

n1 = parseFloat(prompt("Ingresa el numero 1"));
n2 = parseFloat(prompt("Ingresa el numero 2"));
res = n1 + n2;
console.log (n1 + "+" + n2 + "=" + res);
console.log("el resultado de la suma es:" + res);


//Confirm Valores de true o false //Regresa boolean
//alert //Saca un cuadrito 

if (edad > 18){
    console.log();
}
else{

}
