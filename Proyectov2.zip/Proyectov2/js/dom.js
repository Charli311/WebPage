'use strict'

document.writeln("Hola --");



//Create element
var parrafo = document.createElement("p");

parrafo.innerHTML="parrafo 1";
parrafo.id = "parrafo";

document.body.appendChild(parrafo);

parrafo.style.background = "red";
parrafo.style.color = "white";

/*var parra = document.getElementsById("parrafo");
var pa = document.getElementsByClassName("noso");

var pa = document.querySelector(".noso");

parra.style.color = "red";
parra.style.background = "blue";*/

var parr2 = document.createElement("p");
parr2.innerHTML = "parrafo 2";
parr2.className = "noso";
document.body.appendChild(parr2);

/*var pa = document.getElementsByClassName("noso");
pa.style.color = "red";
pa.style.background = "blue";*/
parr2.style.color = "yellow";

var bot = document.createElement("button");
bot.innerHTML = "Cambia color";
document.body.appendChild(bot);
bot.addEventListener("click", change);

function change(){
    parr2.style.color = "blue";
}