'use strict'

var n1;
var n2;
var opcion = true;
var res;

alert ("Calculadora de JavaScript");

while (opcion) {

    n1 = parseFloat(prompt("Ingresa el numero 1"));
    n2 = parseFloat(prompt("Ingresa el numero 2"));

    var oper = prompt("Que operacion desea realizar? 1.Suma 2.Resta 3.Multiplicacion 4.Division");
    oper = parseInt(oper);
    switch (oper) {
        case 1:
            res = n1 + n2;
            alert(res);
            break;
        case 2:
            res = n1 - n2;
            alert(res);
            break;
        case 3:
            res = n1 * n2;
            alert(res);
            break;
        case 4:
            res = n1 / n2;
            alert(res);
            break;
        default : 
        alert ("No es un numero valido");
    }
    opcion = confirm ("Desea hacer otra operacion?");
}






/*function Suma(num1,num2) {
    resultado = num1 + num2;
    return resultado;
}
/*
function Resta(num1,num2) {
    resultado = num1 - num2;
    return resultado;
}

function Multiplicacion(n1,n2) {
    resultado = n1 * n2;
    return resultado;
}

function Division(n1,n2) {
    resultado = n1 / n2;
    return resultado;
}*/