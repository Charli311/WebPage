<?php
include 'conexion.php';

$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$contrasena = $_POST['contrasena'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];

$sql = mysqli_query($con, "INSERT INTO usuarios(id,nombre,edad,nivel,contrasena,telefono,email) values (0,'$nombre','$edad','R','$contrasena', '$telefono', '$email')");
if ($sql) {
    header("Location: ../Pages/ProdAdmin.html");
}
else{
}
?>
