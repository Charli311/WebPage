<?php
include 'conexion.php';

$email = $_POST['emailElim'];
$sql = mysqli_query($con, "DELETE FROM usuarios WHERE email = '$email'");
if ($sql) {
    header("Location: ../Pages/UsrAdmin.html");
}
else{
}
?>