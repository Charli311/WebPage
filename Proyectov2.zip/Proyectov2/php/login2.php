<?php
include 'conexion.php';

session_start();

#$tel = $_POST["telefono"];
$email = $_POST['email'];
$contrasena = $_POST['password'];
$contr = null;

/*if($email == 'admin@admin' && $contrasena == 'admin'){
    header("Location: ../pages/ProdAdmin.html");
}
else {
    $usr = mysqli_query($con, "SELECT * FROM usuarios WHERE email = '$email' AND contrasena = '$contrasena'");
    if (mysqli_num_rows($usr) == 1) {
        header("Location: ../Pages/ProyectoTutMusica.html");
    }
    else {
        header("Location: ../Forms/Login.html");
    }
}*/

$usr = mysqli_query($con, "SELECT * FROM admon WHERE email = '$email' AND password = '$contrasena'");
if(mysqli_num_rows($usr)){
    header("Location: ../pages/ProdAdmin.html");
}
else {
    $usr = mysqli_query($con, "SELECT * FROM usuarios WHERE email = '$email' AND contrasena = '$contrasena'");
    if (mysqli_num_rows($usr) == 1) {
        $user = mysqli_fetch_array($usr);
        $_SESSION ['id_usr'] = $user['id'];
        header("Location: ../Pages/ProyectoTutMusica.html");
    }
    else {
        header("Location: ../Forms/Login.html");
    }
}
?>