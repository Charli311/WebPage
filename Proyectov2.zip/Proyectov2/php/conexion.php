<?php
$server = "localhost";
$database = "cosmicmusic";
$username = "root";
$passwd = "";
//$con = mysqli_connect($server, $username, $passwd, $database);
$con = new mysqli($server, $username, $passwd, $database);

/*if(!$con){
    echo "conexion no lograda";
}
else {
    echo "conexion exitosa";
}*/
?>