<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music</title>
    <link rel="stylesheet" href="../Forms/FormStyle.css">
</head>
<nav class="navegation">
    <div class="right">
        <ul>
            <li><a href="../Forms/Login.html">Log out</a></li>
            <li>Administrador</li>
        </ul>
    </div>
    <ul>
        <li><a href="../Pages/ProdAdmin.html">Productos</a></li><!--productos-->
        <li><a href="../Pages/UsrAdmin.html">Usuarios</a></li>
    </ul>
</nav>
</html>
<?php
include 'conexion.php';

$nombre = $_POST['Snombre'];

$result = mysqli_query($con, "SELECT * FROM product WHERE name = '$nombre'");

$s = '<table border="1">';
foreach ( $result as $row ) {
        $s .= '<tr>';
        foreach ( $row as $v ) {
                $s .= '<td>'.$v.'</td>';
        }
        $s .= '</tr>';
}
$s .= '</table>';
echo $s;
echo ("Regresa a la pagina principal");


?>