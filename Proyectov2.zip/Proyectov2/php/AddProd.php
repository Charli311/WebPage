<?php
include 'conexion.php';

$nombre = $_POST['nombre'];
$price = $_POST['price'];
$descripcion = $_POST['descripcion'];
$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));

$sql = mysqli_query($con, "INSERT INTO product(id,name,descripcion,price,images) values (0,'$nombre','$descripcion','$price', '$image')");
if ($sql) {
    header("Location: ../Pages/ProdAdmin.html");
}
else{
}
?>