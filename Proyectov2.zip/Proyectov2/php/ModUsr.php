<?php
include 'conexion.php';

$nombre = $_POST['nombreMod'];
$edad = $_POST['edadMod'];
$contrasena = $_POST['contrasenaMod'];
$telefono = $_POST['telefonoMod'];
$email = $_POST['emailMod'];


#$sql = mysqli_query($con, "UPDATE usuarios SET nombre = '$nombre' WHERE email = '$email'");
if ($_POST['ModNombre']) {
    $sql = mysqli_query($con, "UPDATE usuarios SET nombre = '$nombre' WHERE email = '$email'");
    header("Location: ../Pages/UsrAdmin.html");
}
if ($_POST['ModContra']) {
    $sql = mysqli_query($con, "UPDATE usuarios SET contrasena = '$contrasena' WHERE email = '$email'");
    header("Location: ../Pages/UsrAdmin.html");
}
if ($_POST['ModEdad']) {
    $sql = mysqli_query($con, "UPDATE usuarios SET edad = '$edad' WHERE email = '$email'");
    header("Location: ../Pages/UsrAdmin.html");
}
if ($_POST['ModTel']) {
    $sql = mysqli_query($con, "UPDATE usuarios SET telefono = '$telefono' WHERE email = '$email'");
    header("Location: ../Pages/UsrAdmin.html");
}


#update usuarios set email = "saul@correo.com" where id=2;
?>