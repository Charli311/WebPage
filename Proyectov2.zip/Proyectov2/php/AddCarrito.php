<?php

session_start();
include 'conexion.php';

$prodID = $_POST['iDProd'];
$prodname = $_POST['Nombre'];
$prodprice = $_POST['Precio'];
if (isset($_SESSION['id_usr'])){
    $userid = $_SESSION['id_usr'];
    #echo $userid;
    $sql = mysqli_query($con, "INSERT INTO cart(id,idprod,userid,nameprod,priceprod) values (0,'$prodID','$userid','$prodname','$prodprice')");
    if ($sql) {
        header("Location: ../Pages/Cursos.php");
    }
}
else{
    header("Location: ../Forms/Login.html");
}

?>