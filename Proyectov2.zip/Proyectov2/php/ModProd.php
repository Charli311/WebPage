<?php
include 'conexion.php';

$id = $_POST['IDMod'];
$nombre = $_POST['nombreMod'];
$desc = $_POST['descripcionMod'];
$price = $_POST['priceMod'];


if ($_POST['ModNombre']) {
    $sql = mysqli_query($con, "UPDATE product SET name = '$nombre' WHERE id = '$id'");
    header("Location: ../Pages/ProdAdmin.html");
}
if ($_POST['ModDesc']) {
    $sql = mysqli_query($con, "UPDATE product SET descripcion = '$desc' WHERE id = '$id'");
    header("Location: ../Pages/ProdAdmin.html");
}
if ($_POST['ModPrice']) {
    $sql = mysqli_query($con, "UPDATE product SET price = '$price' WHERE id = '$id'");
    header("Location: ../Pages/ProdAdmin.html");
}
?>