<?php
include 'conexion.php';

$tel = $_POST["telefono"];
$contrasena = $_POST['password'];
$contr = null;

$usr = mysqli_query($con, "SELECT * FROM usuarios WHERE telefono = '$tel' AND contrasena = '$contrasena'");

if (mysqli_num_rows($usr) == 1) {
    header("Location: ProyectoTutMusica.html");
}
else{
    echo "No se pudo";
    header("Location: Login.html");
}
?>