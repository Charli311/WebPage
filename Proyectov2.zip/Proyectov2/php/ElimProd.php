<?php
include 'conexion.php';

$nombre = $_POST['nombreElim'];
$sql = mysqli_query($con, "DELETE FROM product WHERE name = '$nombre'");
if ($sql) {
    header("Location: ../Pages/ProdAdmin.html");
}
else{
}
?>