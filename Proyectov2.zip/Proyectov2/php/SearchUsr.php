<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music</title>
    <link rel="stylesheet" href="../Forms/FormStyle.css">
</head>
<nav class="navegation">
    <div class="right">
        <ul>
            <li><a href="../Forms/Login.html">Log out</a></li>
            <li>Administrador</li>
        </ul>
    </div>
    <ul>
        <li><a href="../Pages/ProdAdmin.html">Productos</a></li><!--productos-->
        <li><a href="../Pages/UsrAdmin.html">Usuarios</a></li>
    </ul>
</nav>
</html>
<?php
include 'conexion.php';

$email = $_POST['Semail'];

$result = mysqli_query($con, "SELECT * FROM usuarios WHERE email = '$email'");

/*while($row = mysqli_fetch_array($result)) {
    echo $row[0];
    echo $row[1];
    echo $row[2];
    echo $row[3];
    echo $row[4];
    echo $row[5];
    echo $row[6];
}*/
/*echo '<table border="1">';
foreach ( $result as $row ) {
        echo '<tr>';
        foreach ( $row as $v ) {
                echo '<td>'.$v.'</td>';
        }
        echo '</tr>';
}
echo '</table>';*/
$s = '<table border="1">';
foreach ( $result as $row ) {
        $s .= '<tr>';
        foreach ( $row as $v ) {
                $s .= '<td>'.$v.'</td>';
        }
        $s .= '</tr>';
}
$s .= '</table>';
echo $s;
echo ("Regresa a la pagina principal");


?>