<?php
include 'conexion.php';

$userid = $_POST['nombre'];
$producto = $_POST['price'];
$prod = "Curso Guitarra";

$sql = mysqli_query($con, "INSERT INTO cart(id,producto,userid) values (0,'$prod',1)");
if ($sql) {
    header("Location: ../Pages/Cursos.html");
}
else{
}
?>