<?php
include 'conexion.php';

$userid = $_POST['nombre'];
$producto = $_POST['price'];
$prod = "Curso Piano";

$sql = mysqli_query($con, "INSERT INTO cart(id,producto,userid) values (0,'$prod',1)");
if ($sql) {
    header("Location: ../Pages/Cursos.html");
}
else{
}
?>

/*$n = null;
    $real2 = null;
    /*foreach ($result as $r) {
        $temp = mysqli_fetch_array($result);
        $temp2 = $temp['idprod'];
        $real = mysqli_query($con, "SELECT * FROM product WHERE id = '$temp2'");
        $temp3 = mysqli_fetch_array($real);
        $real2 .= $temp3['name'];
        echo $real2;
    }
    /*$temp = mysqli_fetch_array($result);
    $temp2 = $temp['idprod'];
    $real = mysqli_query($con, "SELECT * FROM product WHERE id = '$temp2'");
    $real2 = mysqli_fetch_array($real);
    $s = '<table border="1">';
    foreach ( $real as $row ) {
        $s .= '<tr>';
        foreach ( $row as $v ) {
                $s .= '<td>'.$v.'</td>';
        }
        $s .= '</tr>';
    }
    $s .= '</table>';
    echo $s;
}
else {
    $e = '<p>Inicia Sesion </p>';
    echo $e;
}*/
/*$s = '<table border="1">';
foreach ( $result as $row ) {
        $s .= '<tr>';
        foreach ( $row as $v ) {
                $s .= '<td>'.$v.'</td>';
        }
        $s .= '</tr>';
}
$s .= '</table>';
echo $s;*/